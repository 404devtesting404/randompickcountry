<?php $__env->startSection('title'); ?>
    <?php echo e($data['name']); ?> | Random Country Generator
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="text-center mb-4">
            <h1 class="fw-bold display-5 text-primary"><?php echo e($data['name']); ?></h1>
        </div>

        
        <div class="row">
            <div class="col-md-8">
                <div class="row align-items-center mb-4">

                    
                    <div class="col-md-6 text-center mb-4 mb-md-0">
                        <img src="<?php echo e($data['flag']); ?>" alt="Flag of <?php echo e($data['name']); ?>" class="img-fluid rounded shadow"
                            style="max-width: 280px;">
                    </div>

                    
                    <div class="col-md-6">
                        <h4 class="mb-3 text-secondary">Country Info</h4>
                        <ul class="list-unstyled fs-5">
                            <li><strong>🏛 Capital:</strong> <?php echo e($data['capital']); ?></li>
                            <li><strong>🌍 Region:</strong> <?php echo e($data['region']); ?></li>
                            <li><strong>👥 Population:</strong> <?php echo e(number_format($data['population'])); ?></li>
                            <li><strong>📏 Area:</strong> <?php echo e(number_format($data['area'])); ?> km²</li>
                            <li><strong>🗣 Languages:</strong> <?php echo e($data['languages']); ?></li>
                            <li><strong>💱 Currency:</strong> <?php echo e($data['currency']); ?></li>
                        </ul>
                    </div>
                </div>

                
                <?php if($data['latlng']): ?>
                    <div class="mb-5">
                        <iframe class="w-100 rounded shadow" height="350"
                            src="https://maps.google.com/maps?q=<?php echo e($data['latlng'][0]); ?>,<?php echo e($data['latlng'][1]); ?>&z=4&output=embed"
                            allowfullscreen loading="lazy">
                        </iframe>
                    </div>
                <?php endif; ?>

                
                <div class="text-center">
                    <form method="GET" action="<?php echo e(route('nextrandom')); ?>">
                        <button type="submit" class="btn btn-primary btn-lg px-5 rounded-pill shadow">
                            Next Random Country
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="bg-light p-4 rounded shadow-sm mb-4">
                    <h4 class="mb-3 text-primary fw-semibold">👥 Largest Populations</h4>
                    <ul class="list-unstyled mb-0">
                        <li><a href="<?php echo e(route('country.show', ['China'])); ?>">🌍 China</a></li>
                        <li><a href="<?php echo e(route('country.show', ['India'])); ?>">🌍 India</a></li>
                        <li><a href="<?php echo e(route('country.show', ['United-States-of-America'])); ?>">🌍 United States
                                of America</a></li>
                        <li><a href="<?php echo e(route('country.show', ['Indonesia'])); ?>">🌍 Indonesia</a></li>
                        <li><a href="<?php echo e(route('country.show', ['Pakistan'])); ?>">🌍 Pakistan</a></li>
                        <li><a href="<?php echo e(route('country.show', ['Brazil'])); ?>">🌍 Brazil</a></li>
                    </ul>

                </div>

                <div class="bg-light p-4 rounded shadow-sm">
                    <h4 class="mb-3 text-success fw-semibold">📏 Largest Sizes</h4>
                    <ul class="list-unstyled mb-0">
                        <li><a href="<?php echo e(route('country.show', ['Russia'])); ?>">🌍Russia</a></li>
                        <li><a href="<?php echo e(route('country.show', ['Canada'])); ?>">🌍Canada</a></li>
                        <li><a href="<?php echo e(route('country.show', ['China'])); ?>">🌍China</a></li>
                        <li><a href="<?php echo e(route('country.show', ['United-States-of-America'])); ?>">🌍United States of America</a></li>
                        <li><a href="<?php echo e(route('country.show', ['Brazil'])); ?>">🌍Brazil</a></li>
                    </ul>
                </div>
            </div>

            

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\random-country\resources\views/country/show.blade.php ENDPATH**/ ?>