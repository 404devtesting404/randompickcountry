<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($data['name'] ?? 'Country Info'); ?> - Country Info</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(to right, #e3f2fd, #fce4ec);
            color: #333;
        }

        header {
            background-color: #0d47a1;
            padding: 20px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            animation: slideDown 0.6s ease-in-out;
        }

        .logo {
            color: white;
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
        }

        nav {
            display: flex;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 1rem;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #bbdefb;
        }

        .container {
            max-width: 1100px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.8s ease-in-out;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.4rem;
            color: #0d47a1;
        }

        img.flag {
            display: block;
            margin: 0 auto 25px;
            border-radius: 8px;
            width: 180px;
        }

        ul {
            list-style: none;
            font-size: 1rem;
            padding-left: 20px;
        }

        ul li {
            margin: 10px 0;
            position: relative;
        }

        ul li::before {
            position: absolute;
            left: -20px;
        }

        iframe {
            width: 100%;
            height: 350px;
            border: none;
            border-radius: 12px;
            margin-top: 25px;
        }

        form {
            text-align: center;
            margin-top: 40px;
        }

        button {
            background-color: #0d47a1;
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 30px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
        }

        button:hover {
            background-color: #1565c0;
        }

        footer {
            background-color: #0d47a1;
            color: white;
            padding: 40px 20px;
            text-align: center;
            margin-top: 60px;
            animation: slideUp 0.8s ease-in-out;
        }

        footer p {
            font-size: 1rem;
            margin-bottom: 10px;
        }

        footer a {
            color: #bbdefb;
            text-decoration: none;
            margin: 0 12px;
            transition: color 0.3s;
        }

        footer a:hover {
            color: white;
        }

        @keyframes  fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes  slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes  slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                align-items: flex-start;
            }

            nav a {
                margin: 10px 0 0 0;
            }

            h1 {
                font-size: 1.8rem;
            }

            .container {
                padding: 20px;
            }

            button {
                width: 100%;
            }

            footer a {
                display: block;
                margin: 8px 0;
            }
        }

        /* Contact Section */
        .contact-section {
            padding: 50px 20px;
            background-color: #f5f5f5;
            animation: fadeInUp 1s ease;
        }

        .contact-container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .section-title {
            text-align: center;
            color: #1976d2;
            margin-bottom: 25px;
            font-size: 28px;
        }

        .contact-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .contact-form input,
        .contact-form textarea {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        .contact-form button {
            background-color: #1976d2;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .contact-form button:hover {
            background-color: #0f5bb5;
        }

        /* Animation */
        @keyframes  fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 600px) {
            .contact-section {
                padding: 30px 10px;
            }

            .section-title {
                font-size: 24px;
            }
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin: 20px auto;
            max-width: 700px;
            font-size: 1rem;
            animation: fadeIn 0.5s ease-in-out;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 5px solid #28a745;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 5px solid #dc3545;
        }

        .list-unstyled a {
            text-decoration: none;
            /* underline hatana */
            color: #333;
            /* normal color */
            font-weight: 500;
            /* thoda bold */
            display: inline-block;
            /* padding ke liye */
            padding: 5px 0;
            transition: color 0.3s ease;
            /* smooth hover color change */
        }

        .list-unstyled a:hover {
            color: #007bff;
            /* hover pe blue ya apna choice */
        }
    </style>
</head>

<body>
    

    <header>
        <a href="<?php echo e(route('country.random')); ?>" class="logo">🌎 RandomCountry</a>
        <nav>
            <a href="<?php echo e(route('country.random')); ?>">Home</a>
            <a href="https://random.country/" target="_blank">Original Site</a>
            <a href="#contact">Contact</a>
        </nav>
    </header>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <div class="alert-message">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <section id="contact" class="contact-section">
        <div class="contact-container">
            <h2 class="section-title">📬 Contact Us</h2>
            <form method="POST" action="<?php echo e(route('contactus')); ?>" class="contact-form">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </div>
    </section>

    <footer>
        <p>Copyright © 2025 · All Rights Reserved.</p>
        <p>
            <a href="<?php echo e(route('country.random')); ?>">Home</a> |
            <a href="#contact">Contact</a> |
            <a href="https://random.country/" target="_blank">Source</a>
        </p>
    </footer>
</body>

</html>
<?php /**PATH D:\laragon\www\random-country\resources\views/layouts/app.blade.php ENDPATH**/ ?>